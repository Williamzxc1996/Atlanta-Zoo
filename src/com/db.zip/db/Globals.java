package com.db;


import java.sql.Connection;

public class Globals {

    static Connection con = null;
    static String activeUser;


    static String staffAnimalName;
    static String staffAnimalSpecies;
    static String staffAnimalAge;
    static String staffAnimalType;
    static String staffAnimalExhibit;






} // end class
